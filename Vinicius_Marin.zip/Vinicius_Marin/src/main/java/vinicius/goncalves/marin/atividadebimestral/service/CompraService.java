package vinicius.goncalves.marin.atividadebimestral.service;

import org.springframework.stereotype.Service;
import vinicius.goncalves.marin.atividadebimestral.model.Compra;
import vinicius.goncalves.marin.atividadebimestral.repository.CompraRepository;

import java.util.List;

@Service
public class CompraService {
    private final CompraRepository compraRepository;

    public CompraService(CompraRepository compraRepository) {
        this.compraRepository = compraRepository;
    }

    public void salvar(Compra compra) {
        compraRepository.save(compra);
    }

    public List<Compra> listar() {
        return compraRepository.findAll();
    }
}
