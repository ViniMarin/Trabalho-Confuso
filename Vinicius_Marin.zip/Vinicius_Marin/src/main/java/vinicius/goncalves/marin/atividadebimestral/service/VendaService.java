package vinicius.goncalves.marin.atividadebimestral.service;

import org.springframework.stereotype.Service;
import vinicius.goncalves.marin.atividadebimestral.model.Venda;
import vinicius.goncalves.marin.atividadebimestral.repository.VendaRepository;

import java.util.List;

@Service
public class VendaService {
    private final VendaRepository vendaRepository;

    public VendaService(VendaRepository vendaRepository) {
        this.vendaRepository = vendaRepository;
    }

    public void salvar(Venda venda) {
        vendaRepository.save(venda);
    }

    public List<Venda> listar() {
        return vendaRepository.findAll();
    }
}
