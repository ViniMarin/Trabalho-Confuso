package vinicius.goncalves.marin.atividadebimestral.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import vinicius.goncalves.marin.atividadebimestral.model.Compra;
import vinicius.goncalves.marin.atividadebimestral.service.CompraService;

@Controller
@RequestMapping("/compras")
public class CompraController {
    private final CompraService compraService;

    public CompraController(CompraService compraService) {
        this.compraService = compraService;
    }

    @GetMapping
    public String mostrarPaginaCompras(Model model) {
        model.addAttribute("compras", compraService.listar());
        model.addAttribute("compra", new Compra());
        return "compra";
    }

    @PostMapping
    public String salvar(@ModelAttribute Compra compra) {
        compraService.salvar(compra);
        return "redirect:/compras";
    }
}
