package vinicius.goncalves.marin.atividadebimestral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadebimestralApplicationTests {

	@Test
	void contextLoads() {
	}

}
