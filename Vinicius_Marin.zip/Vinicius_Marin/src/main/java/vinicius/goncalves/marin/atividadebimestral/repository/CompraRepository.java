package vinicius.goncalves.marin.atividadebimestral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vinicius.goncalves.marin.atividadebimestral.model.Compra;

public interface CompraRepository extends JpaRepository<Compra, Long> {}
