package vinicius.goncalves.marin.atividadebimestral.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import vinicius.goncalves.marin.atividadebimestral.model.Venda;
import vinicius.goncalves.marin.atividadebimestral.service.VendaService;

@Controller
@RequestMapping("/vendas")
public class VendaController {
    private final VendaService vendaService;

    public VendaController(VendaService vendaService) {
        this.vendaService = vendaService;
    }

    @GetMapping
    public String mostrarPaginaVendas(Model model) {
        model.addAttribute("vendas", vendaService.listar());
        model.addAttribute("venda", new Venda());
        return "venda";
    }

    @PostMapping
    public String salvar(@ModelAttribute Venda venda) {
        vendaService.salvar(venda);
        return "redirect:/vendas";
    }
}
