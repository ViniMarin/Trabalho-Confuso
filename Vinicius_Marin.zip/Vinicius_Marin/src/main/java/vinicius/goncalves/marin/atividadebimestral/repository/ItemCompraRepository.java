package vinicius.goncalves.marin.atividadebimestral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vinicius.goncalves.marin.atividadebimestral.model.ItemCompra;

public interface ItemCompraRepository extends JpaRepository<ItemCompra, Long> {
}
