package vinicius.goncalves.marin.atividadebimestral.Dto;

public class ResumoProdutoDTO {
    private String nome;
    private int totalComprado;
    private int totalVendido;

    public ResumoProdutoDTO(String nome, int totalComprado, int totalVendido) {
        this.nome = nome;
        this.totalComprado = totalComprado;
        this.totalVendido = totalVendido;
    }

    public String getNome() {
        return nome;
    }

    public int getTotalComprado() {
        return totalComprado;
    }

    public int getTotalVendido() {
        return totalVendido;
    }
}
