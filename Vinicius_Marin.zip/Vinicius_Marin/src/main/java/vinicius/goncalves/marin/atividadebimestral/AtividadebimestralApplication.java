package vinicius.goncalves.marin.atividadebimestral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadebimestralApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadebimestralApplication.class, args);
	}

}
