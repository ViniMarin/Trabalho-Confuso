package vinicius.goncalves.marin.atividadebimestral.service;

import org.springframework.stereotype.Service;
import vinicius.goncalves.marin.atividadebimestral.Dto.ResumoProdutoDTO;
import vinicius.goncalves.marin.atividadebimestral.model.Produto;
import vinicius.goncalves.marin.atividadebimestral.repository.ProdutoRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<ResumoProdutoDTO> gerarResumo() {
        List<Produto> produtos = produtoRepository.findAll();
        List<ResumoProdutoDTO> resumo = new ArrayList<>();

        for (Produto produto : produtos) {
            int totalComprado = produto.getItensCompra() != null
                    ? produto.getItensCompra().stream()
                    .mapToInt(item -> item.getQuantidade() != null ? item.getQuantidade() : 0)
                    .sum()
                    : 0;

            int totalVendido = produto.getItensVenda() != null
                    ? produto.getItensVenda().stream()
                    .mapToInt(item -> item.getQuantidade() != null ? item.getQuantidade() : 0)
                    .sum()
                    : 0;

            resumo.add(new ResumoProdutoDTO(produto.getNome(), totalComprado, totalVendido));
        }

        return resumo;
    }
}
