package vinicius.goncalves.marin.atividadebimestral.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import vinicius.goncalves.marin.atividadebimestral.model.Produto;
import vinicius.goncalves.marin.atividadebimestral.repository.ProdutoRepository;

import java.util.List;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoRepository produtoRepository;

    public ProdutoController(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    // Exibe o formulário para cadastrar um novo produto
    @GetMapping("/novo")
    public String novoProduto(Model model) {
        model.addAttribute("produto", new Produto());
        return "produto-form";
    }

    // Salva o produto cadastrado
    @PostMapping("/salvar")
    public String salvarProduto(@ModelAttribute Produto produto) {
        produtoRepository.save(produto);
        return "redirect:/produtos/lista";
    }

    // Lista todos os produtos cadastrados
    @GetMapping("/lista")
    public String listarProdutos(Model model) {
        List<Produto> produtos = produtoRepository.findAll();
        model.addAttribute("produtos", produtos);
        return "produto-lista";
    }

    // Página de resumo com total de compras e vendas por produto
    @GetMapping("/resumo")
    public String resumoProdutos(Model model) {
        List<Produto> produtos = produtoRepository.findAll();
        model.addAttribute("produtos", produtos);
        return "produto-resumo";
    }
}
